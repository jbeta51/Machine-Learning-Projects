Change directory to directory where files are extracted. Then Change directory to go in RL_sim directory.
Execute the command 'java -jar rl_sim.jar'

For each of the algorithms listed in the paper, load maps 6 and 8 and use the gui to run experiments described.