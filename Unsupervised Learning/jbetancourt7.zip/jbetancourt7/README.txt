To run any of the experiments mentioned in the analysis, you must have
installed python 2.7, along with numpy, scikit-learn, matplotlib.

Scroll to the bottom of the .py file to see the 'main method' where I call my functions.
Each function is an isolated output/experiment, comment out ones you don't want to run.

If graphs are too hard to see in the paper, find them in the figs folder.