For this assignment, I used ABAGAIL. I cloned the repo and built my java files
directly inside the project.

To run code:
Open the file ABAGAIL using a Java IDE like intelliJ.
To run NN weight experiments, right click the file named 
RandomAlgos.java in intelliJ and run it from the drop down menu.
Find main method and TODO comments and see messages to change experimental values
	(i.e. tuning hyperparams, num iterations, etc.)
To run optimization problems, navigate to src/opt/tests and open the test folder.
In intelliJ, right click the file and run it.
Specifically run FourPeaksTest.java and MaxKColoringTest.java.

Jorge Betancourt
